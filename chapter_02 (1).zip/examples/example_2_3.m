% Example 2.3
clear;

% test data ...
day = 3;

% switch example
switch day
    case 1
        day_name = 'Monday';
    case 2
        day_name = 'Tuesday';
    case 3
        day_name = 'Wednesday';
    case 4
        day_name = 'Thursday';
    case 5
        day_name = 'Friday';
    case 6
        day_name = 'Saturday';
    case 7
        day_name = 'Sunday';
    otherwise
        day_name = 'Unknown';
end
