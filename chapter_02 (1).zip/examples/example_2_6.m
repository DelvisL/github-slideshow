% Example 2.6
clear;

% while example
i=randi(10) -1; % random integer between 0 and 9
guess = -1;
while (guess ~= i)
    guess = input('Guess a number:');
    if (guess == i)
        disp('Correct!');
    else
        disp('Wrong, try again ...');
    end
end
