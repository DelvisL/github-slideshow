% Example 2.10
clear;

% continue example
total = 0;
for i = 1:10
    n = input('Enter number: ');
    if (n < 0)
        disp('Ignoring!');
        continue;
    end
    total = total + n;
end
disp(['Total = ' num2str(total)]);
