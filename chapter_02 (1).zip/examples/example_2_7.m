% Example 2.7
clear;

% efficiency example
tic
nRands = 1000000; 
for i=1:nRands 
    rand_array(i) = rand(1); 
end
toc
