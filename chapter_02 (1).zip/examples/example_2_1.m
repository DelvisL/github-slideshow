% Example 2.1
clear;

% if statement example
a = input('Enter a number:');
if (a >= 0)
    root = sqrt(a);
    disp(['Square root = ' num2str(root)]);
else
    disp(['Number is -ve, there is no square root']);
end
