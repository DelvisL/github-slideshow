% Example 2.11
clear;

% nesting example
n = input('Enter number: ');
while (n >= 0)
    f = 1;
    for i = 2:n
        f = f * i;
    end
    disp(f);
    n = input('Enter number: ');
end
