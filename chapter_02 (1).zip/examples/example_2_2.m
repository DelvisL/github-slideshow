% Example 2.2
clear;

% test data ...
gender = 'f'; calories = 2100;

% relational/logic operators example
at_risk = false;
if (gender == 'm') && (calories > 2500)
    at_risk = true;
end
if (gender == 'f') && (calories > 2000)
    at_risk = true;
end