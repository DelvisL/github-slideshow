% Example 2.4
clear;

% test data ...
day = 3;

% switch example
switch day
    case {1,2,3,4,5}
        day_name = 'Weekday';
    case {6,7}
        day_name = 'Weekend';
    otherwise
        day_name = 'Unknown';
end
