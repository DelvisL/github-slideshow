% Example 2.8
clear;

% efficiency example
tic
nRands = 1000000;
rand_array = zeros(1,nRands); 
for i=1:nRands 
    rand_array(i) = rand(1); 
end
toc
