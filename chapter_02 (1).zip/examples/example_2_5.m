% Example 2.5
clear;

% ask user for input
n = input('Enter number:');
f = 1;
if (n >= 0)
    for i = 2:n
        f = f * i;
    end
    disp(['The factorial of ' num2str(n) ' is ' num2str(f)]);
else
    disp(['Cannot compute factorial of -ve number']);
end
