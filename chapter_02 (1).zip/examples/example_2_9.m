% Example 2.9
clear;

% break example
total = 0;
while (true)
    n = input('Enter number: ');
    if (n < 0)
        disp('Finished!');
        break;
    end
    total = total + n;
end
disp(['Total = ' num2str(total)]);
