% Activity 2.6
clear; close all;

% for exercise
asum = 0;
for a=1:5
    asum = asum + a^3 + a^2 + a;
end
asum
