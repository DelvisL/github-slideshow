% Activity 2.3
clear; close all;

% trigonometry exercise
op = input('Enter operation - (s)ine, (c)osine, (t)angent:','s');
n = input('Enter number:');
switch op
    case 's'
        disp(['Sin(' num2str(n) ') = ' num2str(sin(n))]);
    case 'c'
        disp(['Cos(' num2str(n) ') = ' num2str(cos(n))]);
    case 't'
        disp(['Tan(' num2str(n) ') = ' num2str(tan(n))]);
    otherwise
        disp('Invalid character');
end
