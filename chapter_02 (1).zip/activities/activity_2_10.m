% Activity 2.10
clear; close all;

% break/continue exercise
sum = 0;
for x=1:20
    n = input('Enter a number:');
    if (n < 0)
        continue;
    end
    if (n == 0)
        break;
    end
    sum = sum + sqrt(n);
end
disp(['Sum of square roots = ' num2str(sum)]);
