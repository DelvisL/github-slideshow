% Activity 2.8
clear; close all;

% while exercise
c = 'y';
while (c == 'y')
    num = rand(1,1)
    c = input('Continue? ','s');
end
