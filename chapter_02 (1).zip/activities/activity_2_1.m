% Activity 2.1
clear; close all;

% BMI ...
height = input('Enter height in metres: ');
weight = input('Enter weight in kilograms: ');
BMI = weight / (height^2);
if (BMI <= 18.5)
    disp('Underweight');
else
    if (BMI <= 25)
        disp('Normal');
    else
        if (BMI <= 30)
            disp('Overweight');
        else
            disp('Obese');
        end
    end
end
