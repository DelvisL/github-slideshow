% Activity 2.4
clear; close all;

% heart rate exercise
hr = input('Enter heart rate:');
if (hr < 60)  || (hr > 100)
    disp('Warning, abnormal heart rate');
end
