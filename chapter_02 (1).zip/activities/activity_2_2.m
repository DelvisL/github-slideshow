% Activity 2.2
clear; close all;

% operator precedence
a=1; b=2; c=3;

a+b * c
% 7
a ^ b+c
% 4
2 * a == 2 && c - 1 == b
% true (MatLab displays Boolean values as either 1 for true or
%  0 for false)
b + 1:6
% [3 4 5 6]
