% Activity 2.9
clear; close all;

% while/continue exercise
c = 'y';
while (c == 'y')
    n = input('How many numbers? ');
    if (n < 1)
        continue;
    end
    num = rand(1,n)
    c = input('Continue? ','s');
end
