% Activity 2.5
clear; close all;

% heart rate exercise
hr = input('Enter heart rate:');
if (hr < 60)
    disp('Warning, bradycardia');
else
    if (hr > 100)
        disp('Warning, tachycardia');
    else
        disp('Normal heart rate');
    end
end
