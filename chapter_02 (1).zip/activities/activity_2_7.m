% Activity 2.7

% Determine drug dose escalation

% initial dose in mg/kg
dose = 0.2

% determine increment based on iteration of the rule
for x = 1:9
    switch x
        case 1
            increment = 0.67;
        case 2
            increment = 0.5;
        case 3
            increment = 0.4;
        otherwise
            increment = 0.33;
    end
    
    % apply dose escalation
    dose = dose + dose * increment
end
