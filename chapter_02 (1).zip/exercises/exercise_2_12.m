% Exercise 2.12
clear; close all;

% ISS exercise
ais = [3 0 4 5 3 0];
iss = 0;
for x=1:3
    % find value/index of maximum ais score
    [c,i] = max(ais);
    % add on square of highest ais to iss
    iss = iss + c*c;
    % remove highest ais from list
    ais = [ais(1:i-1) ais(i+1:end)];
end
iss
