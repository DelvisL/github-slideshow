% Exercise 2.2
clear; close all;

% CRT response exercise

% test data ...
%nyha_pre = 4; sixmwd_pre = 170; ef_pre = 25;
%nyha_post = 3; sixmwd_post = 220; ef_post = 30;
nyha_pre = 3; sixmwd_pre = 200; ef_pre = 33;
nyha_post = 2; sixmwd_post = 230; ef_post = 45;

% Decide response
if ((nyha_pre - nyha_post) >= 1) && ...
   (((sixmwd_post - sixmwd_pre) / sixmwd_pre) > 0.1) && ...
   ((ef_post - ef_pre) > 10)
    disp('Responder');
else
    disp('Non-responder');
end
