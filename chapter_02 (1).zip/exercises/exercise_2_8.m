% Exercise 2.8
clear; close all;

% load and separate data
load('LAnkle_tracking.mat');
times = LAnkle(:,1);
z = LAnkle(:,4);

% plot data
plot(times, z, '-k');
title('Inferior-superior left ankle motion over time');
xlabel('Time (seconds)');
ylabel('Inferior-superior left ankle motion (mm)');

% Find peaks: need to check 2 either side to find trough ...
footStrikeTimes = [];
numMeasurements = length(z);
for t=3:numMeasurements-2

    % find troughs - version 1 (finds a 'false' foot strike)
%     if (z(t-1) > z(t)) && (z(t) < z(t+1)) 
%         footStrikeTimes(end+1) = times(t);
%     end
    
    % find troughs - version 2 (looks 2 values either side)
    if (z(t-1) > z(t)) && (z(t-2) > z(t-1)) && ...
       (z(t) < z(t+1)) && (z(t+1) < z(t+2))
        footStrikeTimes(end+1) = times(t);
    end
end

% display foot strike time
footStrikeTimes
