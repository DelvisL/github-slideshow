% Exercise 2.6
clear; close all;

% expression exercise
N = input('Enter N: ');
val = 0;
for n=1:N
    val = val + (n+1)/sqrt(n) + n^2;
end
val
