% Exercise 2.9
clear; close all;

% Taylor series exercise
x = input('Enter x: ');
val = 1;
for n=1:10 % can change the 10
    val = val + (x^n)/factorial(n);
end
val
exp(x)
