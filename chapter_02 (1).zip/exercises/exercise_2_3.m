% Exercise 2.3
clear; close all;

% arithmetic exercise
x = input('Enter operand 1: ');
y = input('Enter operand 2: ');
op = input('Enter operation (+,-,*,/): ', 's');
switch op
    case '+'
        disp(['Result = ' num2str(x+y)]);
    case '-'
        disp(['Result = ' num2str(x-y)]);
    case '*'
        disp(['Result = ' num2str(x*y)]);
    case '/'
        disp(['Result = ' num2str(x/y)]);
    otherwise
        disp('Invalid operation');
end
