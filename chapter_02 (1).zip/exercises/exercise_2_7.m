% Exercise 2.7
clear; close all;

% code timing exercise

% Implementation 1 (using array processing):
tic
x = 0:0.00001:(2*pi);
y = sin(x) + 0.5 * cos(x);
plot(x,y);
toc

% Implementation 2 (using iterative construct):
tic
y = [];
for x = 0:0.0001:(2*pi)
    y = [y; sin(x) + 0.5 * cos(x)];
end
plot(0:0.0001:(2*pi),y);
toc

% The first implementation should run faster because MATLAB will allocate
% memory for the entire array once. In the second implementation MATLAB
% will not know how big the array should be and may have to copy it to a
% different part of the computer's memory to make extra space.
