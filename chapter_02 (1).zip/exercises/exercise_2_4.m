% Exercise 2.4
clear; close all;

% blood pressure exercise
dia = input('Enter diastolic pressure:');
sys = input('Enter systolic pressure:');
if (sys < 90) && (dia < 60)
    disp('Low b.p.');
else
    if (sys < 120) && (dia < 80)
        disp('Ideal b.p.');
    else
        if (sys < 140) && (dia < 90)
            disp('Pre-high b.p.');
        else
            disp('High b.p.');
        end
    end
end
