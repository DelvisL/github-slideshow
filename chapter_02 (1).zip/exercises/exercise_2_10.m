% Exercise 2.10
clear; close all;

% Taylor series exercise

% read x and compute correct answer e^x
x = input('Enter x: ');
correct = exp(x);

% loop over number of terms in expansion
nTerms = 1;
close_enough = false;
while ~close_enough
    
    % compute Taylor series
    estimated = 1;
    for n=1:(nTerms-1)
        estimated = estimated + (x^n)/factorial(n);
    end
    
    % close enough?
    if (abs(estimated - correct) < 0.01)
        close_enough = true;
    else
        % increment number of terms
        nTerms = nTerms + 1;
    end
end

disp(['e^' num2str(x) ' = ' num2str(correct)]);
disp(['Accurate to 0.01 for ' num2str(nTerms) ' terms']);
