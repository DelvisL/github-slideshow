% Exercise 2.1
clear; close all;

% CRT exercise

% test data ...
nyha = 3, sixmwd = 250; ef = 30;
%nyha = 4, sixmwd = 170; ef = 25;
%nyha = 2, sixmwd = 210; ef = 40;
%nyha = 3, sixmwd = 200; ef = 33;

% Select patient
if (nyha >= 3) && (sixmwd < 225) && (ef < 35)
    disp('Patient suitable for CRT');
else
    disp('Patient not suitable for CRT');
end
