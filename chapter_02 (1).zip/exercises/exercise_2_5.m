% Exercise 2.5
clear; close all;

% grades exercise
grade = 'c';
switch grade
    case {'a', 'A'}
        disp('Excellent');
    case {'b', 'B'}
        disp('Good');
    case {'c', 'C'}
        disp('OK');
    case {'d', 'D'}
        disp('Below average');
    case {'f', 'F'}
        disp('Fail');
    otherwise
        disp('Unknown grade');
end
