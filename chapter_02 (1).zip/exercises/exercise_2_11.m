% Exercise 2.11
clear; close all;

% Trigonometry exercise
op = ' '; % initialise so loop is entered
while (op ~= 'x')
    op = input('Enter (s)ine, (c)osine, (t)angent, e(x)it:','s');
    if (op ~= 'x') % only if 'x' not entered
        n = input('Enter number:');
        if abs(n) > 2*pi
            disp('Too big ...');
            continue;
        end
        switch op
            case 's'
                disp(['Sin(' num2str(n) ') = ' num2str(sin(n))]);
            case 'c'
                disp(['Cos(' num2str(n) ') = ' num2str(cos(n))]);
            case 't'
                disp(['Tan(' num2str(n) ') = ' num2str(tan(n))]);
            otherwise
                disp('Invalid character');
        end
    end
end
