% Exercise 2.13
clear; close all;

% Divisible by 9 exercise

% read number and convert to integer
num = input('Enter number (<1000): ');
num = int16(num);

% one iteration for each application of rule
apply_rule = true;
while apply_rule
    digit1 = idivide(num, 100); % 100's
    num = num - digit1*100;
    digit2 = idivide(num, 10);  % 10's
    digit3 = mod(num, 10);      % 1's
    
    % sum digits
    num = digit1 + digit2 + digit3;
    
    % more applications of rule required?
    if (num < 10)
        apply_rule = false;
    end
end

% display message
if (num == 9)
    disp('Divisible by 9');
else
    disp('Not divisible by 9');
end
